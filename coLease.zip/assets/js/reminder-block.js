$('.reminder-block__table-card').hover(function() {
  $(this).prev().toggleClass('hidden');
});